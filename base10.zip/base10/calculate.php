<?php

$c = $f = $k = $r = 0;

function cek_data($data){
    if(isset($_GET[$data]) == true){
        if($_GET[$data] == NULL){
            return 0;
        }else{
            return $_GET[$data];
        }
    }else{
        return 0;
    }
}

function cel_conv($cel){
    // global = memanggil apapun dari luar fungsi
    global $c,$f,$k,$r;
    $c = $cel;
    $f = ($cel * 9/5) + 32;
    $k = $cel + 273.15;
    $r = $cel * 4/5;
}

function fare_conv($fare){
    // global = memanggil apapun dari luar fungsi
    global $c,$f,$k,$r;
    $c = ($fare - 32) * 5/9;
    $f = $fare;
    $k = ($fare + 459.67) * 5/9;
    $r = ($fare - 32) * 4/9;
}

function kelv_conv($kelv){
    // global = memanggil apapun dari luar fungsi
    global $c,$f,$k,$r;
    $c = $kelv - 273.15;
    $f = $kelv - 273.15 * (9/5) + 32;
    $k = $kelv;
    $r = $kelv - 273.15 * 4/5;
}

function rea_conv($rea){
    // global = memanggil apapun dari luar fungsi
    global $c,$f,$k,$r;
    $c = $rea * 5/4;
    $f = $rea * 9/4 + 32;
    $k = $rea * 5/4 + 273.15 ;
    $r = $rea;
}

$dor = cek_data("dor");

if($dor == "celci"){
    cel_conv(cek_data("celcius"));
}else if($dor == "fare"){
    fare_conv(cek_data("farenheit"));
} else if($dor == "kelv"){
    kelv_conv(cek_data("kelvin"));
}else if($dor == "rea"){
    rea_conv(cek_data("reamur"));
}
?>