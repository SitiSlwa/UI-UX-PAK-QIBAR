# white true
# break = patahkan looping/perulangan
# continue = melanjutkan looping
# random = ngacak


# while True:
#     a = int(input("= "))
#     if a == 1:
#         print("lanjut mba")
#         continue
#     elif a == 5:
#         print("stop mba")
#         break

import random #ini buat panggil fungsi random
ril = random.randint(1,20) #panggil fungsi dari random integer (dari,sampai)
#ril isinya adalah angka random dari 1 sampai 20
while True: #ini perulangan yang based on benar
    tebak = int(input("Tebak angkany! = ")) #buat input tebakannya
    if tebak == ril: #jika isi tebak sama dengan ril
        print("Tertebak!\nAngkanya adalah", ril) #\n itu sama dengan <br>
        break #selesaiin loopingnya
    else:
        print("EAKKKKKKKK \nKM SALAH")
