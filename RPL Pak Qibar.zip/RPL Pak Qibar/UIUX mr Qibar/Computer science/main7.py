#while
# var = var + x (operator assignment)
# a = 0
# print(a)
# a = a+1
# print(a)
# a = a+1
# print(a)
# a = a+1
# print(a)

ang = int(input("masukan angka awal?"))
ung = int(input("masukan angka akhir?"))
while ang <= ung:
    print(ang)
    ang = ang + 2