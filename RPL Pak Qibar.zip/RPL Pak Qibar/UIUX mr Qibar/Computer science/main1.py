# Tools yang harus ada di laptop
# 1. Phyton versi 3.????????
# 2. Pastikan sudah ditambahkan lokasi phyton di environment windowsnya
# 3. Install Extension "Code Runner" di vsCode
# 4. Setelah install ext di vscode, buka settign -> search executor map -> pastikan perintah phyton di setting sama dengan di terminal
# 5. buka setting vscode -> search run in terminal -> ceklis
# 6. jadi

# Peraturan variabel
# 1. tidak boleh didahulukan dengan angka
# 2. jika dua kata menggunakan snake case (underscore)
# 3. penggunaan case (camel, snake, kebab)

# Tipe Data
# 1. Integer = Angka Bulat
# 2. String = karakter apapun di dalam ""
# 3. Float = Angka desimal
# 4. Boolean = Benar atau salah
# 5. list = kumpulan variabel di dalam variabel

# Milestone
# 1. Input
# 2. Controls (Conditional, Looping)
# 3. Conditionals (if, else, elif, match, shorthand)
# 4. Looping (While, White True, for, for(param1), for(param2), for(param3))
# 5. Funtion (void, with param, with return)
# 6. OOP (Encapsulation, Abstraction, Polymoprh, Inheritance)