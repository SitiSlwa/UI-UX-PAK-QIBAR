p = int(input("masukin panjang"))
l = int(input("masukin lebar"))
t = int(input("masukin tinggi"))
rumus = p * l * t
print(rumus*10000)