# malaikat = boolean
# a = 10
# b = 6
# print(a < b)

# if else elif

# jika boolean:
# output jika boolean true
# lainnya:
# output jika boolean false

umur = int(input("masukan umur!"))
if umur > 16:
    print("anda dapat ktp")
else:
    print("anda masih kicik")