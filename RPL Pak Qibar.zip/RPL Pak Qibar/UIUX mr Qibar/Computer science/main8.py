#ODD EVEN GENERATOR

while True:
    print("ODD EVEN GENERATOR")
    print("1. Ganjil")
    print("2. Genap")
    cois = int(input("= "))
    if cois == 1:
        ang = 1
        while ang < 10:
            print(ang)
            ang = ang + 2
    elif cois == 2:
        ang = 1
        while ang < 10:
            print(ang)
            ang = ang + 2
            break
