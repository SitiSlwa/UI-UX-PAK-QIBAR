# string fromatting
# mengubah semua tipe data menjadi string
# print(f"{angka}{huruf}")

# operator
#  + - * / % (modulus)

nama = input("Masukan Nama?")
tahun = int(input("Masukan tahun sekarang?"))
rumus = 2025 - tahun
print(f"Halloo {nama}")
print(f"umur kamu adalah = {rumus}")