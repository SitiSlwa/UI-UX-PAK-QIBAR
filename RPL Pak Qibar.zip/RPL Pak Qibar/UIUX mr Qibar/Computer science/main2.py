nama = input("Halo nama kmu siapa?")
umur = input("Halo umur kmu berapa")
print("HAIIIIIIIII",nama)
print("wah, ternyata kamu udah",umur)