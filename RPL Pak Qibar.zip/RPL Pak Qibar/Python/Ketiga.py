pi = 3.14
jari_jari = int(input("Masukan jari jarinya"))
rumus = pi * jari_jari * jari_jari
print("Luas Lingkaran : ", rumus)