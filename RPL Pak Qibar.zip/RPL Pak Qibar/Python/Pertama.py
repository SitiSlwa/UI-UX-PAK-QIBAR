nama = input("Masukan Nama Anda? ")
print(nama)
# nama = Variabel
# variabel bisa di isi dengan data apapun
# input("pertanyaan")