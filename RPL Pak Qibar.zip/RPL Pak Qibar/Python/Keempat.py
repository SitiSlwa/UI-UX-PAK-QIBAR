# looping
#berulang2

import time,os

a = 10
b = 10
for i in range(1, 11):
    print(" "*a + "🎂" * i)
    time.sleep(0.5)
    os.system("cls")
    a = a - 1

for i in range(1, 11):
    print(" "*b + "🎂" * i)
    b = b - 1

print("Happy Birthday Betania!!")