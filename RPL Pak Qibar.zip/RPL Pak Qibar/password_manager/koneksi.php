<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "password";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi Gagal: " . mysqli_connect_error());
}

define('KUNCI_RAHASIA', 'kunci-rahasia-tutorial');
?>