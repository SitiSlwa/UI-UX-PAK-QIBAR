<?php
session_start();

// Set session login menjadi true
$_SESSION['login'] = true;

header("Location: home.php");
exit;
?>