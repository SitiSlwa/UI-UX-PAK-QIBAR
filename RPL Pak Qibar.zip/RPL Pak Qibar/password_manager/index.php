<?php
session_start();

// Jika sudah login, langsung lempar ke home
if (isset($_SESSION['login'])) {
    header("Location: home.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Selamat Datang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { height: 100vh; display: flex; align-items: center; justify-content: center; background: #f0f2f5; }
        .welcome-card { text-align: center; padding: 40px; background: white; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="welcome-card">
        <h1 class="mb-3">🔐 Password Manager</h1>
        <p class="text-muted mb-4">Aplikasi Pencatatan Kata Sandi Sederhana</p>
        <a href="login.php" class="btn btn-success btn-lg px-5">Masuk Aplikasi</a>
    </div>
</body>
</html>