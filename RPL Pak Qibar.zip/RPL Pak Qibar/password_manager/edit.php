<?php
session_start();
include 'koneksi.php';

// Cek login
if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM passwords WHERE id = $id");
$row = mysqli_fetch_assoc($data);

// Dekripsi password untuk ditampilkan
$pass_asli = openssl_decrypt(
    base64_decode($row['password_akun']), 
    "AES-128-CBC", 
    KUNCI_RAHASIA, 
    0, 
    str_repeat(chr(0), 16)
);

if (isset($_POST['update'])) {
    $layanan = $_POST['layanan'];
    $username_akun = $_POST['username_akun'];
    $password_akun = $_POST['password_akun'];

    $password_enkripsi = base64_encode(
        openssl_encrypt(
            $password_akun, 
            "AES-128-CBC", 
            KUNCI_RAHASIA, 
            0, 
            str_repeat(chr(0), 16)
        )
    );

    $query = "UPDATE passwords SET layanan='$layanan', username_akun='$username_akun', password_akun='$password_enkripsi' WHERE id=$id";
    
    if (mysqli_query($koneksi, $query)) {
        header("Location: home.php");
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Password</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { 
            min-height: 100vh;
            padding: 20px;
        }
        .form-card {
            border: none;
            border-top: 4px solid #ffc107;
            border-radius: 12px;
        }
        .form-card .card-header {
            background: linear-gradient(to right, #ffc107, #fd7e14);
            border-radius: 12px 12px 0 0 !important;
            color: white;
            font-weight: 600;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
        }
        .input-group-text {
            background: #f8f9fa;
            border-right: none;
        }
        .form-control {
            border-left: none;
        }
        .btn-show-pass {
            border-left: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container d-flex align-items-center justify-content-center" style="min-height: 100vh;">
        <div class="card shadow form-card mx-auto" style="max-width: 500px; width: 100%;">
            <div class="card-header py-3">
                <h5 class="mb-0"><i class="bi bi-pencil-square me-2"></i>Edit Password</h5>
            </div>
            <div class="card-body p-4">
                <form method="post">
                    <!-- Layanan -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold">
                            <i class="bi bi-globe me-1 text-primary"></i>Nama Layanan
                        </label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-link-45deg"></i></span>
                            <input type="text" name="layanan" class="form-control" 
                                   value="<?= htmlspecialchars($row['layanan']); ?>" required>
                        </div>
                    </div>

                    <!-- Username -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold">
                            <i class="bi bi-person me-1 text-primary"></i>Username / Email
                        </label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-at"></i></span>
                            <input type="text" name="username_akun" class="form-control" 
                                   value="<?= htmlspecialchars($row['username_akun']); ?>" required>
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold">
                            <i class="bi bi-key me-1 text-primary"></i>Kata Sandi
                        </label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-lock"></i></span>
                            <input type="password" name="password_akun" class="form-control" 
                                   id="passwordInput" value="<?= htmlspecialchars($pass_asli); ?>" required>
                            <button type="button" class="btn btn-outline-secondary btn-show-pass" 
                                    onclick="togglePassword()">
                                <i class="bi bi-eye" id="toggleIcon"></i>
                            </button>
                        </div>
                        <small class="text-muted">Password akan dienkripsi ulang setelah disimpan</small>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="home.php" class="btn btn-secondary">
                            <i class="bi bi-x-circle me-1"></i>Batal
                        </a>
                        <button type="submit" name="update" class="btn btn-warning px-4">
                            <i class="bi bi-check-circle me-1"></i>Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const input = document.getElementById('passwordInput');
            const icon = document.getElementById('toggleIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            }
        }
    </script>
</body>
</html>