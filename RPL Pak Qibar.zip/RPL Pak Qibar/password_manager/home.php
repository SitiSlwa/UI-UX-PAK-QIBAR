<?php
session_start();
include 'koneksi.php';

// Cek apakah sudah login
if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

$query = "SELECT * FROM passwords ORDER BY id DESC";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-dark mb-4">
        <div class="container">
            <span class="navbar-brand">🔐 Password Manager</span>
            <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4>Daftar Kata Sandi</h4>
            <a href="tambah.php" class="btn btn-success">+ Tambah Baru</a>
        </div>

        <div class="card shadow">
            <div class="card-body">
                <?php if (mysqli_num_rows($result) === 0) : ?>
                    <p class="text-center text-muted">Belum ada data.</p>
                <?php else : ?>
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Layanan</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                                <?php 
                                    $pass_asli = openssl_decrypt(
                                        base64_decode($row['password_akun']), 
                                        "AES-128-CBC", 
                                        KUNCI_RAHASIA, 
                                        0, 
                                        str_repeat(chr(0), 16)
                                    ); 
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['layanan']); ?></td>
                                    <td><?= htmlspecialchars($row['username_akun']); ?></td>
                                    <td><code><?= htmlspecialchars($pass_asli); ?></code></td>
                                    <td>
                                        <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <a href="hapus.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>