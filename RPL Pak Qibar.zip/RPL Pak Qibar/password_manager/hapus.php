<?php
session_start();
include 'koneksi.php';

// Cek login
if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM passwords WHERE id = $id");

header("Location: home.php");
?>