<?php
// cara mengambil semua data dalam table
// select*from table_name

// cara mengisi table
// insert into table_name values()
// 1, 'Olahraga', 'Mr. Galih', 'Kamis'

$x = mysqli_connect(
    "localhost",
    "root",
    "",
    "xii_pplg2"
);

echo var_dump($x);
?>
    <html>
        <head>
            <title> PHP MY SQL </title>
        </head>
        <body>

        </body>
    </html>