<?php
// list using for
$bahan = ["jagung","labu siam","asem","melinjo"];
echo $bahan[0];
echo "<br>";
echo $bahan[1];
echo "<br>";
echo $bahan[2];
echo "<br>";
echo $bahan[3];
echo "<br>";

$a = 0;
while ($a <= 3){
    echo $a;
    $a++;
}

?>