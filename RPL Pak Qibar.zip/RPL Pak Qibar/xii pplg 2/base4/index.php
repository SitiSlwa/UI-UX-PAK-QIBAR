<?php
// tipe data map
// sama seperti list tpi lebih keren
// masing2 value punya key
// list
$lama = [1, "Mr.Jaka", "React Native"];
// memanggil menggunakan index

// MAP
$baru = [
    "no" => 1,
    "nama" => "Mr Jaka",
    "matpel" => "React Native"
];
//  key => value
echo $baru["nama"];
?>