<?php
//  super global variabel
function cek_data($data){
    if(isset($_GET[$data]) == true){
        return $_GET[$data];
    }else{
        return "nodata";
    }
}
?>

<html>
    <head>
        <title></title>
    </head>
    <body>
        <h1><?php echo cek_data('nama'); ?></h1>
        <h1><?php echo cek_data('nilai'); ?></h1>
        <hr>
        <form action="" method="get">
            <label>Nama</label>
            <input type="text" name="nama">
            <br>
            <label>Nilai</label>
            <input type="number" name="nilai">
            <br>
            <input type="submit" value="Cek Nilai">
        </form>
    </body>
</html>


<!-- buat kkm -->