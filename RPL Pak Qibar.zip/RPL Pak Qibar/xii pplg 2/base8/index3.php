<?php
//  super global variabel
function ujian($data){
    if(isset($_GET[$data]) == true){
        return $_GET[$data];
    }else{
        return "nodata";
    }
}

function hasil($hasil){
    if($hasil >= 75){
        echo "LULUS";
    }else{
        echo "REMEDIAL";
    }
}
    
?>



<html>
    <head>
        <title>Cek KKM</title>
    </head>
    <body>
        <h1><?php echo ujian('nama'); ?></h1>
        <h1><?php echo ujian('nilai'); ?></h1>
        <?php
            // tampilkan hasil lulus / remedial jika nilai ada
        if(ujian('nilai') !== null){
            echo "<h1>" .  hasil(ujian('nilai')) . "</h1>";
    }
    ?>
        <hr>
        <form action="" method="get">
            <label>Nama</label>
            <input type="text" name="nama">
            <br>
            <label>Nilai</label>
            <input type="number" name="nilai">
            <br>
            <input type="submit" value="Skor">
        </form>
    </body>
</html>