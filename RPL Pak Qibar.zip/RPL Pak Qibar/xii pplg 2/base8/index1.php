<?php

function angka1(){
    echo 18;
}
function angka2(){
    return 17; // return = menjadikan fungsi bernilai
}
function angka3($data){// di dalam () bisa berisi variabel, disebut parameter
    echo "<br>";
    echo "data ku =", $data;
}

$umur = 15;
if (angka2() >= 17){
    echo "Dapat KTP";
}else{
    echo "Ga dapat KTP";
}

angka3("too cool");

?>

<!-- perbedaan return dan echo -->
<!-- echo berfungsi untuk menampilkan saja, tidak ada isinya. Jadi kalau kita ganti if nya ke angka 1, maka akan muncul ga dapet -->
<!-- kalau return angka 17 bisa dianggap nilai, jadi dia muncul "dapet" -->