<?php

function db(){
   $koneksi = mysqli_connect(
        "localhost",
        "root",
        "",
        "XII_PPLG_2"
    );
    if ($koneksi->connect_errno == 1){ // jika ya
        return $koneksi->connect_error; // kembalikan pesan error
    }else{
        return $koneksi; // kembalikan nilai connect
    }
}

function tampil() {
   $query = "SELECT * FROM sayur"; //perintah
   $data = mysqli_query(db(), $query); // fungsi sql
   return $data; // memberikan data
}

?>