yang dipelajari PHP:
-OOP
-looping
-return
-Model View Controller

yang dipelajari database:
-auto increment
-Primary key, foreign key
-CRUD

Projek yang pasti ada: manajemen kasir
-tiker hotel
-tiket pesawat
-sistem informasi siswa

alur projek yang pasti approve:
login->tambah item ke keranjang->cetak struk