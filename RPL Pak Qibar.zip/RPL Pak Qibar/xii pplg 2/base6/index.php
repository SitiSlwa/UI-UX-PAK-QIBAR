<!-- pengolahan data -->
<?php
include 'db.php'; //disertakan

$data = mysqli_query(
    $db,
    "SELECT * FROM jadwal"
);
?>
<!-- pengolahan data -->
<!-- tampilan -->
<html>
    <head>
        <title>Sayang sayangku</title>
    </head>
    <body>
        <h1>Daftar Nama Guru Favorite</h1>
        <a href="tambah_guru.php">Tambah</a>
        <table border=1>
            <tr>
                <th>Nomor</th>
                <th>Matpel</th>
                <th>Nama guru</th>
                <th>Hari</th>
            </tr>
        <?php
        foreach($data as $x){
            ?>
            <tr>
                <td><?= $x['no'] ?></td>
                <td><?= $x['mata_pelajaran'] ?></td>
                <td><?= $x['nama_guru'] ?></td>
                <td><?= $x['hari'] ?></td>
            </tr>
            <?php
            // echo $x['no'];
            // echo $x['mata_pelajaran'];
            // echo $x['nama_guru'];
            // echo $x['hari'];
        };
        ?>
        </table>
    </body>
</html>
<!-- tampilan -->