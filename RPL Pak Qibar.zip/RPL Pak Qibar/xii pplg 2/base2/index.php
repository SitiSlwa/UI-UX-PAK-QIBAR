<?php

function tembak(){
    echo "Aku anak cerdas, tubuhku kuat\n";
};
    //trigger
    tembak();

    // function with return
    function dor(){
        return 9;
    };

    // if you using return function,
    // this function becomes variable
   echo  dor();

?>