<!-- Funtion masuk ke class jadi method -->
<!-- Variabel masuk ke class jadi atribut -->
<!-- function berguna untuk meringkas coding yang panjang -->
 <!-- variabel = tempat menyimpan nilai -->
<?php
 function best_of_month(){
    echo "Oktober";
 }

?>

<html>
<head>
    <title>Function Fundamental</title>
</head>
<body>
    <h1>
        <?php best_of_month();?>
    </h1>
</body>
</html>