<?php

$label = "Keychain";
function tampil($data){
    return$data;
}

tampil("salwa");
echo ("salwa");

?>